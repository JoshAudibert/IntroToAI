# IntroToAI

NOTE: Python 2.7 was used to write and run this program,
	it will most likely not run with python 3

The program can be run in command line by:

astar.py "Test X.txt" hur_num

Example running Test 1 with heuristic 4:

astar.py "Test 1.txt" 4

Argv[0]: astar.py
Argv[1]: which test the program should run
Argv[2]: integer value from 1 to 6 of which heuristic should be used
