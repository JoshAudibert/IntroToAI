# IntroToAI

NOTE: Python 2.7 was used to write and run this program,
	it will most likely not run with python 3

NOTE: Test file CANNOT have an extra newline at the end of 
	the file or the parsing of the file will not work

The program can be run in command line by:

ga.py problem_num "Test X.txt" time_limit

Example running problem3_test1.txt with problem 3 and a time limit of 10 seconds:

ga.py 3 "problem3_test1.txt" 10

Argv[0]: ga.py
Argv[1]: which problem to run from 1 to 3
Argv[2]: which file to test on
Argv[3] the time limit of the program in seconds
